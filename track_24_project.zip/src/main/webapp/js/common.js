/**
 * 
 */

function checkEmpty(obj,msg){
	if(obj.value==""){
		alert(msg);
		obj.focus();
		return true;
	}else {
		return false;
	}
} 